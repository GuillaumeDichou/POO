package main.java.itshop;

import main.java.itshop.model.*;
import java.util.List;
import java.util.Scanner;

public class ClientMode {
    private final List<Product> availableProducts;
    private final Inventory inventory;

    public ClientMode(List<Product> availableProducts, Inventory inventory) {
        this.availableProducts = availableProducts;
        this.inventory = inventory;
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Customer mode ---");
            System.out.println("1. Show available products");
            System.out.println("2. Order a product");
            System.out.println("3. Return to main menu");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    displayAvailableProducts();
                    break;
                case 2:
                    placeOrder(scanner);
                    break;
                case 3:
                    System.out.println("Return to main menu...");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        } while (choice != 3);
    }

    private void displayAvailableProducts() {
        System.out.println("\n--- Available products ---");
        for (Product product : availableProducts) {
            if (inventory.isInStock(product)) {
                int quantity = inventory.getQuantity(product);
                System.out.println(product.getName() + " - " + product.getPrice() + " dollars (Stock: " + quantity + ")");
            }
        }
    }

    private void placeOrder(Scanner scanner) {
        System.out.print("Name of product to order: ");
        String name = scanner.nextLine();

        Product selected = null;
        for (Product product : availableProducts) {
            if (product.getName().equalsIgnoreCase(name)) {
                selected = product;
                break;
            }
        }

        if (selected == null) {
            System.out.println("Product not found.");
            return;
        }

        if (!inventory.isInStock(selected)) {
            System.out.println("This product is currently out of stock.");
            return;
        }

        System.out.print("Quantity required: ");
        int qty = scanner.nextInt();
        scanner.nextLine();

        if (inventory.getQuantity(selected) < qty) {
            System.out.println("Insufficient stock. Stock on hand: " + inventory.getQuantity(selected));
            return;
        }

        inventory.removeFromStock(selected, qty);
        System.out.println("Order for " + qty + " x " + selected.getName() + ". Thanks!");
    }
}
