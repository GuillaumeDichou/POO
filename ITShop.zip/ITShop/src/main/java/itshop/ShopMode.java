package main.java.itshop;

import main.java.itshop.model.*;
import java.util.List;
import java.util.Scanner;

public class ShopMode {
    private final List<ClientOrder> clientOrders;
    private final Inventory inventory;
    private final List<Supplier> suppliers;

    public ShopMode(List<ClientOrder> clientOrders, Inventory inventory, List<Supplier> suppliers) {
        this.clientOrders = clientOrders;
        this.inventory = inventory;
        this.suppliers = suppliers;
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
            int choice;

            do {
                System.out.println("\n===== Shop Mode =====");
                System.out.println("1. View customer orders");
                System.out.println("2. View stock");
                System.out.println("3. Suppliers list");
                System.out.println("4. Return to main menu");
                System.out.print("Choose an option: ");
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        viewClientOrders();
                        break;
                    case 2:
                        viewStock();
                        break;
                    case 3:
                        manageSuppliers();
                        break;
                    case 4:
                        System.out.println("Return to main menu...");
                        break;
                    default:
                        System.out.println("Invalid option.");
                }
            } while (choice != 4);
    }

    private void viewClientOrders() {
        if (clientOrders.isEmpty()) {
            System.out.println("\nNo pending customer orders.");
            return;
        }

        System.out.println("\nCustomer orders:");
        for (ClientOrder order : clientOrders) {
            System.out.println("- " + order.getProduct().getName() + " (Quantity: " + order.getQuantity() + ")");
        }
    }

    private void viewStock() {
        System.out.println("\nCurrent stock situation:");
        for (Product product : inventory.getAllProducts()) {
            int quantity = inventory.getQuantity(product);
            System.out.println("- " + product.getName() + " | Quantity: " + quantity);
        }
    }    

    private void manageSuppliers() {
        System.out.println("\nList of suppliers:");
        for (Supplier supplier : suppliers) {
            System.out.println("- " + supplier.getName() + " | Adress: " + supplier.getAddress());
        }
    }
}
