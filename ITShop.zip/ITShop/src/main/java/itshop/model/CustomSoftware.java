package main.java.itshop.model;

public class CustomSoftware extends Software {
    private String developer;
    private int estimatedDeliveryTime;

    public CustomSoftware(String name, double price, String developer, int estimatedDeliveryTime) {
        super(name, price, false, estimatedDeliveryTime);
        this.developer = developer;
    }

    @Override
    public int getDeliveryTime() {
        return estimatedDeliveryTime;
    }

    public String getDeveloper() {
        return developer;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

    public void setEstimatedDeliveryTime(int estimatedDeliveryTime) {
        this.estimatedDeliveryTime = estimatedDeliveryTime;
    }
}
