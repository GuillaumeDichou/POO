package main.java.itshop.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Inventory {
    private Map<Product, Integer> stock;

    public Inventory() {
        stock = new HashMap<>();
    }

    public List<Product> getAllProducts() {
        return new ArrayList<>(stock.keySet());
    }


    public void addProduct(Product product, int quantity) {
        stock.put(product, stock.getOrDefault(product, 0) + quantity);
    }

    public boolean isInStock(Product product) {
        return stock.containsKey(product) && stock.get(product) > 0;
    }

    public int getQuantity(Product product) {
        return stock.getOrDefault(product, 0);
    }

    public boolean removeFromStock(Product product, int quantity) {
        if (!isInStock(product) || stock.get(product) < quantity) {
            return false;
        }
        stock.put(product, stock.get(product) - quantity);
        return true;
    }

    public void displayStock() {
        System.out.println("=== CURRENT STOCK ===");
        for (Map.Entry<Product, Integer> entry : stock.entrySet()) {
            Product p = entry.getKey();
            int qty = entry.getValue();
            System.out.println("- " + p.getName() + " (" + qty + ")" + (qty <= 0 ? " [OUT OF STOCK]" : ""));
        }
    }
}
