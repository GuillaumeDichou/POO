package main.java.itshop.model;

public class Service implements Product {
    private String name;
    private double price;
    private int deliveryTime;
    private int stockQuantity;

    public Service(String name, double price, int deliveryTime) {
        this.name = name;
        this.price = price;
        this.deliveryTime = deliveryTime;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public int getDeliveryTime() {
        return deliveryTime;
    }

    @Override
    public boolean isInStock() {
        return true;
    }

    @Override
    public int getStockQuantity() {
        return stockQuantity;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setDeliveryTime(int deliveryTime) {
        this.deliveryTime = deliveryTime;
    }
}
