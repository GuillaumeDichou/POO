package main.java.itshop.model;

import java.util.ArrayList;
import java.util.List;

public class Order {
    protected String orderId;
    protected List<Product> products;
    protected double totalPrice;
    protected int deliveryTime;

    public Order(String orderId) {
        this.orderId = orderId;
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public double calculateTotalPrice() {
        totalPrice = 0;
        for (Product product : products) {
            totalPrice += product.getPrice();
        }
        return totalPrice;
    }

    public int calculateDeliveryTime() {
        deliveryTime = 0;
        for (Product product : products) {
            deliveryTime = Math.max(deliveryTime, product.getDeliveryTime());
        }
        return deliveryTime;
    }

    public String getOrderId() {
        return orderId;
    }

    public List<Product> getProducts() {
        return products;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public int getDeliveryTime() {
        return deliveryTime;
    }
}
