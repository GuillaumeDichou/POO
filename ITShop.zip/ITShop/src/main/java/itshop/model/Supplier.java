package main.java.itshop.model;

import java.util.ArrayList;
import java.util.List;

public class Supplier {
    private String supplierId;
    private String name;
    private String address;
    private List<Product> productsSupplied;

    public Supplier(String supplierId, String name, String address) {
        this.supplierId = supplierId;
        this.name = name;
        this.address = address;
        this.productsSupplied = new ArrayList<>();
    }

    public void addProduct(Product product) {
        productsSupplied.add(product);
    }

    public void removeProduct(Product product) {
        productsSupplied.remove(product);
    }

    public String getSupplierId() {
        return supplierId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<Product> getProductsSupplied() {
        return productsSupplied;
    }
}
