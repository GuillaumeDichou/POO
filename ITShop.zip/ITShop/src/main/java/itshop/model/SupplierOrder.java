package main.java.itshop.model;

public class SupplierOrder extends Order {
    private String supplierName;
    private String supplierAddress;

    public SupplierOrder(String orderId, String supplierName, String supplierAddress) {
        super(orderId);
        this.supplierName = supplierName;
        this.supplierAddress = supplierAddress;
    }

    @Override
    public int calculateDeliveryTime() {
        return super.calculateDeliveryTime();
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getSupplierAddress() {
        return supplierAddress;
    }

    public void setSupplierAddress(String supplierAddress) {
        this.supplierAddress = supplierAddress;
    }
}
