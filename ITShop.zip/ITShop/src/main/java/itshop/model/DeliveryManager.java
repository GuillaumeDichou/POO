package main.java.itshop.model;

public class DeliveryManager {

    public int calculateDeliveryTime(Product product) {
        return product.getDeliveryTime();
    }

    public void assignDeveloper(CustomSoftware software) {
        
    }
}
