package main.java.itshop.model;

public interface Product {
    String getName();
    double getPrice();
    int getDeliveryTime();
    boolean isInStock();
    int getStockQuantity();
}

