package main.java.itshop.model;

import java.util.List;

public class ClientOrder extends Order {
    private String clientName;
    private String clientAddress;
    private Product product;
    private int quantity;

    public ClientOrder(String orderId, String clientName, String clientAddress) {
        super(orderId);
        this.clientName = clientName;
        this.clientAddress = clientAddress;
    }

    public Product getProduct() {
        return this.product;
    }
    
    public int getQuantity() {
        return this.quantity;
    }    

    @Override
    public int calculateDeliveryTime() {
        return super.calculateDeliveryTime();
    }

    public List<Product> getProducts() {
        return products;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientAddress() {
        return clientAddress;
    }

    public void setClientAddress(String clientAddress) {
        this.clientAddress = clientAddress;
    }
}
