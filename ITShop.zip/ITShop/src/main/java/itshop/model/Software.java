package main.java.itshop.model;

public class Software implements Product {
    private String name;
    private double price;
    private boolean inStock;
    private int deliveryTime;
    private int stockQuantity;

    public Software(String name, double price, boolean inStock, int deliveryTime) {
        this.name = name;
        this.price = price;
        this.inStock = inStock;
        this.deliveryTime = deliveryTime;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public int getDeliveryTime() {
        return inStock ? 0 : deliveryTime;
    }

    @Override
    public boolean isInStock() {
        return inStock;
    }

    @Override
    public int getStockQuantity() {
        return stockQuantity;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setInStock(boolean inStock) {
        this.inStock = inStock;
    }

    public void setDeliveryTime(int deliveryTime) {
        this.deliveryTime = deliveryTime;
    }
}
