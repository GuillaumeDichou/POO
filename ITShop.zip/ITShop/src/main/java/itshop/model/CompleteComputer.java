package main.java.itshop.model;

import java.util.List;

public class CompleteComputer extends Hardware {
    private List<Hardware> components;
    private double assemblyFee;

    public CompleteComputer(String name, double price, boolean inStock, int deliveryTime, List<Hardware> components, double assemblyFee) {
        super(name, price, inStock, deliveryTime);
        this.components = components;
        this.assemblyFee = assemblyFee;
    }

    @Override
    public double getPrice() {
        double totalPrice = super.getPrice();
        for (Hardware component : components) {
            totalPrice += component.getPrice();
        }
        return totalPrice + assemblyFee;
    }

    @Override
    public int getDeliveryTime() {
        return isInStock() ? 3 : super.getDeliveryTime();
    }

    public List<Hardware> getComponents() {
        return components;
    }

    public void setComponents(List<Hardware> components) {
        this.components = components;
    }

    public double getAssemblyFee() {
        return assemblyFee;
    }

    public void setAssemblyFee(double assemblyFee) {
        this.assemblyFee = assemblyFee;
    }
}
