package main.java.itshop;

import main.java.itshop.model.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainMenu {

    public static void displayMenu() {
        try (Scanner scanner = new Scanner(System.in)) {
            int choice;

            // Data initialization
            List<Product> availableProducts = initializeProducts();
            Inventory inventory = new Inventory();
            for (Product product : availableProducts) {
                inventory.addProduct(product, 10); // ou autre valeur initiale
            }            
            List<Supplier> suppliers = initializeSuppliers();
            List<ClientOrder> clientOrders = new ArrayList<>();

            do {
                System.out.println("\n1. Client mode");
                System.out.println("2. Shop mode");
                System.out.println("3. Leave");
                System.out.print("Choose an option: ");
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        ClientMode clientMode = new ClientMode(availableProducts, inventory);
                        clientMode.run();
                        break;
                    case 2:
                        ShopMode shopMode = new ShopMode(clientOrders, inventory, suppliers);
                        shopMode.run();
                        break;
                    case 3:
                        System.out.println("Goodbye");
                        break;
                    default:
                        System.out.println("Invalid option");
                }
            } while (choice != 3);
        }
    }

    private static List<Product> initializeProducts() {
        List<Product> products = new ArrayList<>();
        products.add(new Software("Windows", 99.99, true, 0));
        products.add(new Software("MacOS", 129.99, true, 0));
        products.add(new Software("Linux", 99.99, true, 0));
        products.add(new Software("Microsoft Office", 99.99, true, 0));
        products.add(new Software("Adobe", 99.99, true, 0));
        products.add(new Software("Photoshop", 99.99, true, 0));
        products.add(new Software("Norton", 99.99, true, 0));
        products.add(new Software("McAfee", 99.99, true, 0));
        products.add(new Hardware("AMD Ryzen 7 9800X3D", 489.00, true, 5));
        products.add(new Hardware("Intel Core i9-14900K", 438.99, true, 5));
        return products;
    }

    private static List<Supplier> initializeSuppliers() {
        List<Supplier> suppliers = new ArrayList<>();
        suppliers.add(new Supplier("1", "Software supplier", "Adress A"));
        suppliers.add(new Supplier("2", "Hardware supplier", "Adresse B"));
        return suppliers;
    }
}
